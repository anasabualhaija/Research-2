import requests
import time

# Replace with your Arduino's IP address
arduino_ip = "157.181.176.180"  # Example IP, change to your Arduino's
arduino_port = 80  # Default HTTP port

def send_command(command):
    url = f"http://{arduino_ip}:{arduino_port}"
    try:
        response = requests.post(url, data=command)
        #print(f"Arduino responded: {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"Error sending command: {e}")

# Number of iterations
iterations = 10

for i in range(iterations):
    print(f"Starting iteration {i+1}/{iterations}...")

    # Example commands before timing
    send_command("while (digitalRead(21) == LOW) {digitalWrite(33, HIGH); delay(10);} digitalWrite(33, LOW);")
    send_command("while (digitalRead(14) == LOW) {digitalWrite(4, HIGH); delay(10);} digitalWrite(4, LOW);")
    send_command("digitalWrite(19, HIGH);delay(300);digitalWrite(19, LOW)")

    # Start timing after sending the first relevant command
    start_time = time.time()

    # Send timed commands
    send_command("digitalWrite(5, HIGH);digitalWrite(27, HIGH);delay(500);digitalWrite(26, HIGH);digitalWrite(27, LOW);")
    #time.sleep(0.2)
    start_time = time.time()
    send_command("while (digitalRead(22) == LOW) {digitalWrite(19, HIGH); delay(10);} digitalWrite(19, LOW);")
    send_command("digitalWrite(33, HIGH);delay(300);digitalWrite(33, LOW);digitalWrite(27, HIGH);delay(500);digitalWrite(26, LOW);delay(500);digitalWrite(27, LOW);digitalWrite(5, LOW);")
    send_command("while (digitalRead(23) == LOW) {digitalWrite(15, HIGH); delay(10);} digitalWrite(15, LOW);")
    send_command("delay(1000);")
    send_command("while (digitalRead(12) == LOW) {digitalWrite(15, HIGH); delay(10);} digitalWrite(15, LOW);")
    send_command("digitalWrite(5, HIGH);delay(300);digitalWrite(18, HIGH);delay(500);digitalWrite(18, LOW);digitalWrite(32, HIGH);digitalWrite(5, LOW);")
    
    # Stop timing after receiving the response to the second timed command
    send_command("while (digitalRead(13) == HIGH) {digitalWrite(32, HIGH); delay(10);} digitalWrite(32, LOW);")

    # End time
    end_time = time.time()

    # Calculate the elapsed time in milliseconds
    elapsed_time_ms = (end_time - start_time) * 1000

    print(f"Iteration {i+1} elapsed time between commands: {elapsed_time_ms:.2f} ms\n")



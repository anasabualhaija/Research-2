import requests
import time

# Replace with your Arduino's IP address
arduino_ip = "157.181.176.180"  # Change this to your Arduino's IP
arduino_port = 80  # Default HTTP port

def send_commands(commands):
    url = f"http://{arduino_ip}:{arduino_port}"
    headers = {'Content-Type': 'text/plain'}
    try:
        all_commands = '\n'.join(commands) + '\n'  # Combine commands into a single string
        response = requests.post(url, data=all_commands, headers=headers)
        return response.text
    except requests.exceptions.RequestException as e:
        print(f"Error sending commands: {e}")
        return None

# First set of commands (msg 1)
first_commands = [
    "while (digitalRead(21) == LOW) {digitalWrite(33, HIGH); delay(10);} digitalWrite(33, LOW);",
    "while (digitalRead(14) == LOW) {digitalWrite(4, HIGH); delay(10);} digitalWrite(4, LOW);",
    "digitalWrite(19, HIGH);delay(300);digitalWrite(19, LOW);"
]

# Second set of commands (msg 2)
second_commands = [
    "digitalWrite(5, HIGH);digitalWrite(27, HIGH);delay(500);digitalWrite(26, HIGH);digitalWrite(27, LOW);",
    "while (digitalRead(22) == LOW) {digitalWrite(19, HIGH); delay(10);} digitalWrite(19, LOW);",
    "digitalWrite(33, HIGH);delay(300);digitalWrite(33, LOW);digitalWrite(27, HIGH);delay(500);digitalWrite(26, LOW);delay(500);digitalWrite(27, LOW);digitalWrite(5, LOW);",
    "while (digitalRead(23) == LOW) {digitalWrite(15, HIGH); delay(10);} digitalWrite(15, LOW);",
    "delay(1000);",
    "while (digitalRead(12) == LOW) {digitalWrite(15, HIGH); delay(10);} digitalWrite(15, LOW);",
    "digitalWrite(5, HIGH);delay(300);digitalWrite(18, HIGH);delay(500);digitalWrite(18, LOW);digitalWrite(32, HIGH);digitalWrite(5, LOW);",
    "while (digitalRead(13) == HIGH) {digitalWrite(32, HIGH); delay(10);} digitalWrite(32, LOW);"
]

# Number of loops
num_loops = 10

# Loop through the number of loops
for _ in range(num_loops):
    # Send first set of commands
    first_response = send_commands(first_commands)

    # Start timing after receiving the response to the first set
    start_time = time.time()

    # Send second set of commands
    second_response = send_commands(second_commands)

    # Stop timing after receiving the response to the second set
    end_time = time.time()
    elapsed_time_ms = (end_time - start_time) * 1000  # Convert seconds to milliseconds

    # Print the elapsed time
    print(f"Elapsed time between first response and second response: {elapsed_time_ms:.2f} ms")

    # Optionally print the Arduino's response to the second set

    # Short delay before the next loop iteration (optional)
    time.sleep(1)  # Adjust the delay as needed
